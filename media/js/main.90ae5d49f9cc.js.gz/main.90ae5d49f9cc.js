import { toggleDarkMode, toggleUserMenu, profileDropdownMenu, toggleFullScreen } from "./utils.js";
import {ClockTiming } from "./clocking.js";

ClockTiming();
toggleDarkMode();
toggleUserMenu();
profileDropdownMenu();







